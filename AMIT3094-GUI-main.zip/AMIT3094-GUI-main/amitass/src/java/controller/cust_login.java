/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.CustomExceptions;
import model.Customer;

/**
 *
 * @author User
 */
@WebServlet(name = "cust_login", urlPatterns = {"/cust_login"})
public class cust_login extends HttpServlet {
@PersistenceContext EntityManager em;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
        try{
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            Query query = em.createNamedQuery("Customer.findByEmail");
            query.setParameter("email", email); // set the value of the staffId parameter
            Customer result = (Customer) query.getSingleResult(); // execute the query and get the result
            
            if(password.equals(result.getPassword())){
                // Generate Session using base64
                String customerLogin_session = Base64.getEncoder().encodeToString(email.getBytes());
                String customerPassword_session = Base64.getEncoder().encodeToString(result.getPassword().getBytes());
                
                // Store data in Session
                HttpSession session = request.getSession();
                session.setAttribute("customer_login_sesion", customerLogin_session);
                session.setAttribute("customer_password_sesion", customerPassword_session);
                response.sendRedirect("/amitass/index.jsp");
                
            }else{
                throw new CustomExceptions.InvalidCredentials();
            }

            
        }catch (NoResultException | CustomExceptions.InvalidCredentials ex){
            request.setAttribute("errorMessage", ex.getMessage());
            String redirectUrl = "/amitass/cust-login.jsp";
            String script = "<script>alert('Invalid Credentials!!'); window.location.href='" + redirectUrl + "';</script>";
            response.setContentType("text/html");
            response.getWriter().print(script);
        }catch (Exception ex) {
            Logger.getLogger(staff_login.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
