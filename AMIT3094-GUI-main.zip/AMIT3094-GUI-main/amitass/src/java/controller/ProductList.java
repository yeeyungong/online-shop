/* Decompiler 22ms, total 705ms, lines 44 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Shoes;

@WebServlet(
   name = "ProductList",
   urlPatterns = {"/ProductList"}
)
public class ProductList extends HttpServlet {
   @PersistenceContext
   EntityManager em;
   
    private String host = "jdbc:derby://localhost:1527/shoedb";
    private String user = "nbuser";
    private String password = "nbuser";
   
    private String selectRateSql = "SELECT rate FROM REVIEW WHERE shoes_id = ?";
    private String selectAllSql = "SELECT * FROM shoes";
    private String pagingSql = "SELECT * FROM shoes OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    
    private Connection conn;
    
    private PreparedStatement selectPagingStmt;
    private ResultSet selectPagingRs;
    
    private PreparedStatement selectAllStmt;
    private ResultSet selectAllRs;
    
    private PreparedStatement selectRateStmt;
    private ResultSet selectRateRs;
    
    
    
   protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out = response.getWriter();
       List<Shoes> shoesList = new ArrayList<>();
       List<HashMap> rateList = new ArrayList<>();
  
        int p;
         try {
             p = Integer.parseInt(request.getParameter("page"))-1;
         }catch (NumberFormatException ex){
             p = 0;
         }catch (NullPointerException ex) {
             p = 0;
         }
   
        int num_per_page = 12;
        int start_from=(p)*12;
        
        int size = 0;
        try {
            conn = DriverManager.getConnection(host,user,password);
            selectAllStmt = conn.prepareStatement(selectAllSql);
            selectAllRs = selectAllStmt.executeQuery();
            
            while(selectAllRs.next()) {
                size++;
            }
            
            
            //String pagingSql = "SELECT * FROM shoes OFFSET " + start_from + " ROWS FETCH NEXT " + num_per_page + " ROWS ONLY";
            selectPagingStmt = conn.prepareStatement(pagingSql);
            selectPagingStmt.setInt(1, start_from);
            selectPagingStmt.setInt(2, num_per_page);
            selectPagingRs = selectPagingStmt.executeQuery();
            
            selectRateStmt = conn.prepareStatement(selectRateSql);
            Shoes shoes = null;
            while(selectPagingRs.next()) {
                shoes = new Shoes();
                shoes.setShoesId(selectPagingRs.getString("SHOES_ID"));
                shoes.setShoesName(selectPagingRs.getString("SHOES_NAME"));
                shoes.setShoesPng(selectPagingRs.getString("SHOES_PNG"));
                shoes.setShoesPrice(selectPagingRs.getDouble("SHOES_PRICE"));
                shoes.setShoesSize(selectPagingRs.getString("SHOES_SIZE"));
                shoes.setShoesStock(selectPagingRs.getInt("SHOES_STOCK"));
                shoes.setShoesType(selectPagingRs.getString("SHOES_TYPE"));
                
                shoesList.add(shoes);
                
                selectRateStmt.setString(1, shoes.getShoesId());
                selectRateRs = selectRateStmt.executeQuery();
                int rateCount = 0;
                HashMap rateDetail = null;
                int rateValue = 0;
                boolean found = false;
                while(selectRateRs.next()) {
                    found = true;
                    rateDetail = new HashMap();
                    rateValue += selectRateRs.getInt("RATE");
      
                    rateCount++;
                }
                if(found) {
                    rateDetail.put(shoes.getShoesId(),rateValue);
                    rateDetail.put("count", rateCount);
                    rateList.add(rateDetail);
                }
                    
                
            }
            
            
        }catch (SQLException ex) {
            out.println(ex.getMessage());
        }

       
      //Query query = this.em.createNamedQuery("Shoes.findAll");
      HttpSession session = request.getSession();
      session.setAttribute("shoesList", shoesList);
      session.setAttribute("size", size);
      session.setAttribute("productListRate", rateList);
      response.sendRedirect("product.jsp?page=" + (p+1));
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      this.processRequest(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      this.processRequest(request, response);
   }

   public String getServletInfo() {
      return "Short description";
   }
}
