/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author YW VIP
 */
@WebServlet(name = "addToCart", urlPatterns = {"/addToCart"})
public class addToCart extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String shoeId = request.getParameter("shoeId");
            String shoePNG = request.getParameter("shoePNG");
            String shoeName = request.getParameter("shoeName");
            double shoePrice = Double.parseDouble(request.getParameter("shoePrice"));
            int shoeQty = Integer.parseInt(request.getParameter("quantity"));

            HttpSession session = request.getSession();

            List<HashMap> cartList = new ArrayList<>();
            if (session.getAttribute("cartList") != null) {
                cartList = (List<HashMap>) session.getAttribute("cartList");
            }

            int foundIndex = -1;

            for (int i = 0; i < cartList.size(); i++) {
                if (shoeId.equalsIgnoreCase((String) cartList.get(i).get("shoeId"))) {
                    foundIndex = i;
                }
            }

            if (foundIndex != -1) {
                shoeQty += (int) cartList.get(foundIndex).get("shoeQty");
            }

            HashMap shoeDetails = new HashMap();
            shoeDetails.put("shoeId", shoeId);
            shoeDetails.put("shoePNG", shoePNG);
            shoeDetails.put("shoeName", shoeName);
            shoeDetails.put("shoePrice", shoePrice);
            shoeDetails.put("shoeQty", shoeQty);

            if (foundIndex != -1) {
                cartList.set(foundIndex, shoeDetails);

            } else {
                cartList.add(shoeDetails);
            }

            session.setAttribute("cartList", cartList);

            /*Cookie[] cookies = request.getCookies();
             String cartItems = "";
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equalsIgnoreCase("cartItems")) {
                    cartItems = cookies[i].getValue();
                }
            }
            
            String[] splitCartItem = cartItems.split("&");
            //List<StringBuilder> splitCartItemList = new ArrayList<>();
            for(int i = 0; i < splitCartItem.length; i++) {
                //StringBuilder singleCartItem = new StringBuilder(splitCartItem[i]);
                //splitCartItemList.add(singleCartItem);
                //out.println(splitCartItem[i]);
            }
            
            int foundIndex = -1;
             for(int i = 0; i < splitCartItem.length; i++) {
                String[] splitCartItemDetails = splitCartItem[i].split("|");
               /*if(shoeName.equalsIgnoreCase(splitCartItemDetails[1])){
                    foundIndex = i;
                    int cookiesQuantity = Integer.parseInt(splitCartItemDetails[3]);
                    shoeQty += cookiesQuantity;
                    
                }
               for(int j = 0; j < splitCartItemDetails.length; j++) {
                   out.println(splitCartItemDetails[j]);
                   out.println("<br>");
               }
            }*/
 /* StringBuilder cartItem = new StringBuilder(shoePNG + "|" + shoeName + "|" + shoePrice + "|" + shoeQty + "&");
            
            if(foundIndex != -1) {
                splitCartItemList.set(foundIndex, cartItem);
            }else {
                splitCartItemList.add(cartItem);
            }
            
            for(int i = 0; i < splitCartItemList.size(); i++) {
                out.println(splitCartItemList.get(i));
                out.println("<br>");
            }

            
            /*Boolean b = new Boolean(false);
            int cartItemsID = 0;
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equalsIgnoreCase("cartItems")) {
                    b = true;
                    cartItemsID = i;
                }
            }
            if (b) {
                Cookie newC = new Cookie("CartItems", cookies[cartItemsID].getValue() + cartItem);
                response.addCookie(newC);
            } else {
                Cookie c = new Cookie("CartItems", cartItem);
                response.addCookie(c);
            }*/
            response.sendRedirect("product-single.jsp?id=" + shoeId);
        } catch (Exception ex) {
            out.println(ex.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
