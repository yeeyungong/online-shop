/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;
import model.CustomExceptions;
import model.Customer;


/**
 *
 * @author User
 */
@WebServlet(name = "NewPassword", urlPatterns = {"/NewPassword"})
public class NewPassword extends HttpServlet {
    @PersistenceContext EntityManager em;
    @Resource UserTransaction utx;
    private static final String PASSWORD_PATTERN = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^\\w\\d\\s:])([^\\s]){8,20}$";


    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);

    PrintWriter out = response.getWriter();
        try {
          HttpSession mySession = request.getSession();
          String newPsw = request.getParameter("newPassword");
          String confPsw = request.getParameter("confPassword");
          
          Pattern passwordPattern = Pattern.compile(PASSWORD_PATTERN);
          Matcher passwordMatcher = passwordPattern.matcher(newPsw);
          
          if (!passwordMatcher.matches()) {
                    // password is not valid, handle the error
                    throw new CustomExceptions ("Password should be contain at least one digit, uppcase, lowercase character, special symbol and within 8-20 characters!!!");
               }
          String email = (String) mySession.getAttribute("forgotPassEmail");
          
          if(newPsw.equals(confPsw)){
              /*Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/shoedb","nbuser","nbuser");
              PreparedStatement stmt = conn.prepareStatement("UPDATE CUSTOMER SET PASSWORD = ? WHERE EMAIL = ?");
              stmt.setString(1, newPsw);
              stmt.setString(2, email);
              stmt.executeUpdate();*/
              Query query = em.createNamedQuery("Customer.findByEmail");
            query.setParameter("email", email); // set the value of the staffId parameter
            Customer customer = (Customer) query.getSingleResult();
            customer.setPassword(newPsw);
            utx.begin();
            em.merge(customer);
            utx.commit();
            
              String successScript = "<script>alert('Password Reset Successfully!'); window.location.href='/amitass/cust-login.jsp'</script>";
              out.println (successScript);
              //response.sendRedirect("/amitass/cust-login.jsp");


             
          }else{
                    throw new CustomExceptions ("Password are not match, Please try again!");
          }
          
        }catch(NoResultException | CustomExceptions ex){
           String redirectUrl = "/amitass/newPassword.jsp";
           String script = "<script>alert('"+ex.getMessage()+"'); window.location.href='" + redirectUrl + "';</script>";
           out.println (script);

        }catch(Exception ex) {
            out.println(ex.getMessage());
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
