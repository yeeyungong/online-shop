/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Transactions;
import javax.persistence.*;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;
import model.Customer;
import model.Shoes;
import model.TransactionDetails;

/**
 *
 * @author YW VIP
 */
@WebServlet(name = "addTransactions", urlPatterns = {"/addTransactions"})
public class addTransactions extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        try{
            String encodeCustLoginCredential = (String) session.getAttribute("customer_login_sesion");
            List<HashMap> cartList = (List<HashMap>) session.getAttribute("cartList");
            HashMap paymentDetails = (HashMap) session.getAttribute("paymentDetails");
            
            Query query = em.createNamedQuery("Transactions.findAll");
            List<Transactions> transactionsList = query.getResultList();
            //Transaction Id
            String trasactionId = String.format("T%04d", transactionsList.size() + 1);
            //Total Amount
            Double totalAmount = (Double) paymentDetails.get("total");
            //Customer
            Customer customer = null;
            if(session.getAttribute("customer_login_sesion") != null) {
                    String decodeCustLoginCredential = new String(Base64.getDecoder().decode(encodeCustLoginCredential));
                    Query customerQuery = em.createNamedQuery("Customer.findByEmail");
                    customerQuery.setParameter("email", decodeCustLoginCredential);
                    customer = (Customer) customerQuery.getSingleResult();
            }
            //Total quantity
            Integer totalQuantity = 0;
            for(int i = 0; i < cartList.size(); i++) {
                
                totalQuantity += (Integer) cartList.get(i).get("shoeQty");
            }
            //Address
            String address = (String) paymentDetails.get("address");
            
            Integer paymentType = (Integer) paymentDetails.get("paymentType");
            
            
            Transactions transaction = new Transactions();
            transaction.setTransactionId(trasactionId);
            transaction.setTotalAmount(totalAmount);
            transaction.setQuantity(totalQuantity);
            transaction.setCustId(customer);
            transaction.setAddress(address);
            
            
            if(paymentType == 1) {
                String cardType = (String)paymentDetails.get("cardType");
                transaction.setPaymentType(cardType);
                String cardNum = (String)paymentDetails.get("cardNum");
                transaction.setAccountNo(cardNum);

            }else {
                transaction.setPaymentType("Cash");
            }
            
                utx.begin();
                em.persist(transaction);
                utx.commit();
                
           /**
            * Transaction Details
            */
            for(int i = 0; i < cartList.size(); i++) {
                 Query transactionDetailsQuery = em.createNamedQuery("TransactionDetails.findAll");
                List<TransactionDetails> transactionsDetailsList = transactionDetailsQuery.getResultList();
            
                //Transaction Details Id
                String trasactionDetailsId = String.format("D%04d", transactionsDetailsList.size() + 1);
                //Each quantity
                Integer eachQuantity = (Integer) cartList.get(i).get("shoeQty");
                // Each shoes
                String shoesId = (String) cartList.get(i).get("shoeId");
                Shoes shoes = em.find(Shoes.class,shoesId);
                
                Integer stock = shoes.getShoesStock() - eachQuantity;
                shoes.setShoesStock(stock);
                
                TransactionDetails transactionDetails = new TransactionDetails();
                transactionDetails.setDetailsId(trasactionDetailsId);
                transactionDetails.setQuantity(eachQuantity);
                transactionDetails.setTransactionId(transaction);
                transactionDetails.setShoesId(shoes);
                
                utx.begin();
                em.persist(transactionDetails);
                em.merge(shoes);
                utx.commit();
                
                response.sendRedirect("SuccessCheckOut.jsp");
            }
            
        } catch (Exception ex) {
            out.println(ex.getMessage());
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
