/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Customer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import model.CustomExceptions;

/**
 *
 * @author User
 */
@WebServlet(name = "AddCustomer", urlPatterns = {"/AddCustomer"})
public class AddCustomer extends HttpServlet {
     private static final String EMAIL_PATTERN = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
    //[a-zA-Z0-9._%+-]+ - one or more alphanumeric characters, dots, underscores, percent signs, plus signs, or hyphens
    //@ - at sign
    //[a-zA-Z0-9.-]+ - one or more alphanumeric characters, dots, or hyphens
    //\. - literal dot character (escaped with a backslash)
    //[a-zA-Z]{2,} - two or more alphabetic characters (e.g., com, org, edu)
    
     private static final String PASSWORD_PATTERN = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^\\w\\d\\s:])([^\\s]){8,20}$";
  
   //(?=.*\d) - positive lookahead for at least one digit
   //(?=.*[a-z]) - positive lookahead for at least one lowercase letter
   //(?=.*[A-Z]) - positive lookahead for at least one uppercase letter
   //(?=.*[^\w\d\s:]) - positive lookahead for at least one special character that is not a letter, digit, whitespace or colon
    //([^\s]){8,20} - a character class that matches any character that is not whitespace, repeated 8-20 times

     
    @PersistenceContext EntityManager em;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
        PrintWriter out = response.getWriter();
        try {
            

                    Query query = em.createNamedQuery("Customer.findAll");
                    List<Customer> customerList = query.getResultList();
                    
                    int customerSize = customerList.size();
                    
                    //Customer ID
                    String customerID = String.format("C%04d", customerSize+1);
                    String name = request.getParameter("username");
                    String phone = request.getParameter("phone");
                    String email = request.getParameter("email");
                    String password = request.getParameter("password");
                    
                    Pattern emailPattern = Pattern.compile(EMAIL_PATTERN);
                    Matcher emailMatcher = emailPattern.matcher(email);
                    
                    Pattern passwordPattern = Pattern.compile(PASSWORD_PATTERN);
                    Matcher passwordMatcher = passwordPattern.matcher(password);
                    
                    if (!emailMatcher.matches()) {
                    // email address is not valid, handle the error
                    throw  new CustomExceptions ("Email Invalid!");
                     }

                    if (!passwordMatcher.matches()) {
                    // password is not valid, handle the error
                    throw  new CustomExceptions ("Password should be contain at least one digit, uppcase, lowercase character, special symbol and within 8-20 characters!!!");
                    }
                    
                    Customer cust = new Customer(customerID,name,phone,email,password);
                    CustomerDa custDa = new CustomerDa();
                    custDa.addRecord(cust);
                    
                    response.sendRedirect("SuccessfulSignUp.jsp");
                    
                     
        }catch (CustomExceptions ex){
            String redirectUrl = "/amitass/cust-login.jsp";
            String script = "<script>alert('"+ex.getMessage()+"'); window.location.href='" + redirectUrl + "';</script>";
            out.println (script);
        }catch(NumberFormatException ex) {
            out.println(ex.getMessage());
            
        }catch(Exception ex) {
            out.println(ex.getMessage());
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
