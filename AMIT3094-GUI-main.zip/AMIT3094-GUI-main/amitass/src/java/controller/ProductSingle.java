/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import com.sun.jndi.url.rmi.rmiURLContext;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Customer;
import model.Review;
import model.Shoes;
import model.Staff;

/**
 *
 * @author USER
 */
@WebServlet(name = "ProductSingle", urlPatterns = {"/ProductSingle"})
public class ProductSingle extends HttpServlet {
    /*@PersistenceContext 
            EntityManager em;*/
    private String host = "jdbc:derby://localhost:1527/shoedb";
    private String user = "nbuser";
    private String password = "nbuser";
    
    private Connection conn;
    private PreparedStatement selectReviewStmt;
    private ResultSet selectReviewRs;
    
    private PreparedStatement selectShoesStmt;
    private ResultSet selectShoesRs;
    
    private PreparedStatement selectReplyCommStmt;
    private ResultSet selectReplyCommRs;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        PrintWriter out = response.getWriter();
        try {
            String shoesId = request.getParameter("id");
            String selectReviewSql = "SELECT R.review_id,R.rate,R.date_review,R.customer_comm,C.username "
                    + "FROM SHOES S,REVIEW R,CUSTOMER C "
                    + "WHERE R.shoes_id = ? "
                    + "AND R.shoes_id = S.shoes_id "
                    + "AND R.cust_id = C.cust_id";
            
            String selectShoesSql = "SELECT * FROM SHOES WHERE shoes_id = ?";
            
            String selectReplyComm = "SELECT R.reply_comm, S.staff_name "
                        + "FROM REVIEW R, STAFF S "
                        + "WHERE R.review_id = ? "
                        + "AND R.staff_id = S.staff_id";
            
            conn = DriverManager.getConnection(host,user,password);
            
            selectShoesStmt = conn.prepareStatement(selectShoesSql);
            selectShoesStmt.setString(1, shoesId);
            selectShoesRs = selectShoesStmt.executeQuery();
            
            Shoes shoes = null;
            if(selectShoesRs.next()) {
                shoes = new Shoes();
                shoes.setShoesId(selectShoesRs.getString("shoes_id"));
                shoes.setShoesName(selectShoesRs.getString("shoes_name"));
                shoes.setShoesPng(selectShoesRs.getString("shoes_png"));
                shoes.setShoesPrice(selectShoesRs.getDouble("shoes_price"));
                shoes.setShoesSize(selectShoesRs.getString("shoes_size"));
                shoes.setShoesStock(selectShoesRs.getInt("shoes_stock"));
                shoes.setShoesDesc(selectShoesRs.getString("shoes_desc"));
                //shoes.setShoesType(rs.getString("SHOES_TYPE"));
            }
            
            
            
            selectReviewStmt = conn.prepareStatement(selectReviewSql);
            selectReviewStmt.setString(1, shoesId);
            selectReviewRs = selectReviewStmt.executeQuery();
            
            selectReplyCommStmt = conn.prepareStatement(selectReplyComm);
            
            List<Review> reviewList = new ArrayList<>();
            while(selectReviewRs.next()) {
                Review review = new Review();
                review.setRate(selectReviewRs.getInt("rate"));
                review.setDateReview(selectReviewRs.getDate("date_review"));
                review.setCustomerComm(selectReviewRs.getString("customer_comm"));
                
                Customer customer = new Customer();
                customer.setUsername(selectReviewRs.getString("username"));
                
                review.setCustId(customer);
               
                selectReplyCommStmt.setString(1, selectReviewRs.getString("REVIEW_ID"));
                selectReplyCommRs = selectReplyCommStmt.executeQuery();

                String replyComm = null;
                Staff staff = null;
                if (selectReplyCommRs.next()) {
                    replyComm = selectReplyCommRs.getString("REPLY_COMM");
                    staff = new Staff();
                    staff.setStaffName(selectReplyCommRs.getString("STAFF_NAME"));
                }
                
                review.setReplyComm(replyComm);
                review.setStaffId(staff);
                
                reviewList.add(review);
            }
            shoes.setReviewList(reviewList);
            
            HttpSession session = request.getSession();
            session.setAttribute("shoes", shoes);
            
            response.sendRedirect("product-single.jsp?id=" + shoesId);
            
        }catch (Exception ex) {
            out.println(ex.getMessage());
        }
        
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
