/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.CustomExceptions;

/**
 *
 * @author YW VIP
 */
@WebServlet(name = "BankDetails", urlPatterns = {"/BankDetails"})
public class BankDetails extends HttpServlet {
    private final String CARD_NUM_PATTERN = "^\\d{16}$";
    private final String CVV_PATTERN = "^\\d{3}$";
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        HashMap errorCheckout = new HashMap();
        try {
           String cardType = request.getParameter("cardType");
           String cardOwnerName = request.getParameter("ownerName");
           String cardNum = request.getParameter("cardNum");
           String expiryDate = request.getParameter("expiryDate");
           String cvvNum = request.getParameter("cvv");
           
           boolean error = false;
           if(cardType.isEmpty()) {
               error = true;
               errorCheckout.put("errorCardType", "Please select card type");
           }
           
           if(cardOwnerName.isEmpty()) {
               error = true;
               errorCheckout.put("errorOwnerName", "Please fill in card owner name");
           }
           
           Pattern cardNumPattern = Pattern.compile(CARD_NUM_PATTERN);
            Matcher cardNumMatcher = cardNumPattern.matcher(cardNum);
           if(cardNum.isEmpty()) {
               error = true;
               errorCheckout.put("errorCardNum", "Please fill in card number");
           }else if(!cardNumMatcher.matches()) {
               error = true;
               errorCheckout.put("errorCardNum", "Please fill in exactly 16 digits");
           }
           
           if(expiryDate.isEmpty()) {
               error = true;
               errorCheckout.put("errorExpiryDate", "Please fill in card expiry date");
           }
           
            Pattern cvvPattern = Pattern.compile(CVV_PATTERN);
            Matcher cvvMatcher = cvvPattern.matcher(cvvNum);
           if(cvvNum.isEmpty()) {
               error = true;
               errorCheckout.put("errorCvv", "Please fill in CVV");
           }else if(!cvvMatcher.matches()) {
               error = true;
               errorCheckout.put("errorCvv", "Please fill in exactly 3 digits");

           }
           
            
            HashMap paymentDetails = (HashMap) session.getAttribute("paymentDetails");
            
            paymentDetails.put("cardType",cardType);
            paymentDetails.put("cardOwnerName", cardOwnerName);
            paymentDetails.put("cardNum", cardNum);
            paymentDetails.put("expiryDate", expiryDate);
            paymentDetails.put("cvv", cvvNum);
           
            session.setAttribute("paymentDetails",paymentDetails);
            
            if(error) {
                throw new CustomExceptions("Banking Details Input Field Exception");
            }
            
            session.removeAttribute("errorCheckout");

            
               response.sendRedirect("addTransactions");
           
           
        } catch (CustomExceptions ex) {
            session.setAttribute("errorCheckout", errorCheckout);
            response.sendRedirect("BankDetails.jsp");

        } catch (Exception ex) {
            out.println(ex.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
