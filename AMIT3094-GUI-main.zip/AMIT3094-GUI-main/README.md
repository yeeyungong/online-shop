# AMIT3094 Assignment README
This is a Java MVC project for assignment AMIT3094 which is designed using the Model-View-Controller (MVC) architectural pattern. 

## Project structure
The project is structured in the following way:

- `model`: This package contains the model classes of the application.
- `controller`: This package contains the controller classes of the application.

## Dependencies
This project has the following dependencies:
- Java version 8 (JDK 1.8)
- GlassFish Server 5.0

## How to run the application
1. Unzip the compressed project zip file
2. Open the unzipped project in Apache Netbeans IDE
3. Execute the SQL file inside the project

## Additional Information
Database Credentials:
Username: `nbuser`
Password: `nbuser`

Admin page Manager Credentials:
Username: `M1001`
Password: `manager`

Admin page Staff Credentials:
Username: `S1001`
Password: `teng`

Home page Customer Credentials:
Username: `<TODO>`
Password: `<TODO>`